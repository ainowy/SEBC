# SEBC
Services Enablement Boot Camp
http://blog.puneethabm.in/configure-hadoop-security-with-cloudera-manager-using-kerberos/
